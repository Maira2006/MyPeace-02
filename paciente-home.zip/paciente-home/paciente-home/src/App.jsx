
import Conteudo from './conteudo/conteudo';

const App = () => {
  return (
    <div className="App">
      <Conteudo />
    </div>
  );
};

export default App;
