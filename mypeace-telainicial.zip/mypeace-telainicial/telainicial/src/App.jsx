
import './App.css'
import Cabecalho from './cabecalho/cabecalho'
import Rodape from './rodape/rodape'
import Corpo from './corpo/corpo'

function App() {


  return (
    <>
     <Cabecalho></Cabecalho>
     <Corpo></Corpo>
     <Rodape></Rodape>
    </>
  )
}

export default App
