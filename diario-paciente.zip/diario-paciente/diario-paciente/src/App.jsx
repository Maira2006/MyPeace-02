
import './App.css'
import Rodape from './rodape/rodape'
import Cabecalho from './cabecalho/Cabecalho'
import Conteudo from './conteudo/conteudo'

function App() {
  

  return (
    <>
      <Cabecalho/>
      <Conteudo/>
      <Rodape/>
    </>
  )
}

export default App
