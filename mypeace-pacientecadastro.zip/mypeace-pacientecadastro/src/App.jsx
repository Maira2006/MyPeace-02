import { useState } from 'react'
import Cabecalho from './cabeçalho/cabecalho'
import Corpo from './corpo/corpo'
import Rodape from './rodape/rodape'
import './App.css'

function App() {


  return (
    <>
    <Cabecalho></Cabecalho>
    <Corpo></Corpo>
    <Rodape></Rodape>
    </>
  )
}

export default App
