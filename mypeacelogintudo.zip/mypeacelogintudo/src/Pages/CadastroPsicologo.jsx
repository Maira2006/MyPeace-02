import Cadcabecalho from "../CadastroPsicologo/Cadcabecalho/Cadcabecalho";
import Cadconteudo from "../CadastroPsicologo/Cadconteudo/Cadconteudo";
import Cadrodape from "../CadastroPsicologo/Cadrodape/Cadrodape";


export default function CadastroPsicologo(){
    return(
        <>
            <Cadcabecalho/>
            <Cadconteudo/>
            <Cadrodape/>
        </>
    )
}