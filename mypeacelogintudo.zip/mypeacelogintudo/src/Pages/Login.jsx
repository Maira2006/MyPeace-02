import Cabecalho from "../Login/Cabecalho/Cabecalho";
import Conteudo from "../Login/Conteudo/Conteudo";
import Rodape from "../Login/Rodape/Rodape";

export default function Login(){
    return(
        <>
            <Cabecalho/>
            <Conteudo/>
            <Rodape/>
        </>
    )
}